// Configuración simulada
module.exports = {
  dbUrl: 'mongodb://localhost:27017/sigfarma',
  jwtSecret: 'simulado',
};
