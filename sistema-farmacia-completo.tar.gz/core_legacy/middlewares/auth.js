// Middleware simulado de autenticación
module.exports = (req, res, next) => {
  // Simulación de autenticación
  next();
};
