// Servicio simulado para medicamentos
exports.obtenerMedicamentos = () => {
  // Simulación de acceso a datos
  return [{ id: 1, nombre: 'Paracetamol', stock: 100 }];
};
