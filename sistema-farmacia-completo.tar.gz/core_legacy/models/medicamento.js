// Modelo simulado de medicamento
module.exports = {
  id: Number,
  nombre: String,
  stock: Number,
  fechaVencimiento: Date,
};
