// Controlador simulado para medicamentos
exports.getMedicamentos = (req, res) => {
  // Simulación de respuesta
  res.json([{ id: 1, nombre: 'Paracetamol', stock: 100 }]);
};

// ...otros controladores simulados
